# [2.15.5](https://github.com/WeakAuras/WeakAuras2/tree/2.15.5) (2019-10-22)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.15.4...2.15.5)

## Highlights

 - A few more bug fixes 

## Commits

Stanzilla (1):

- drop branch name from PR artifacts

Vardex (1):

- Fix weapon enchant shortened name

mrbuds (2):

- swing timer: fix nil error if no offhand equiped
- update "Cooldown Progress (Equipment Slot)" for handling amno fixes #1762 refresh on UNIT_INVENTORY_CHANGED add a stacksFunc

